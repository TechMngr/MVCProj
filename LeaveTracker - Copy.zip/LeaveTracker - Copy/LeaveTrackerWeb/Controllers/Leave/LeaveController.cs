﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity.Migrations;
using Model = LeaveTrackerWeb.Models;

namespace LeaveTrackerWeb.Controllers.Leave
{
    [Authorize]
    public class LeaveController : Controller
    {
        // GET: Leave
        public ActionResult ApplyLeave()
        {
            return View();
        }
        [HttpGet]
        public ActionResult LeaveDetails()
        {
            return View();
           
        }
        [HttpGet]
        public ActionResult Holidays()
        {
            using (Model.ApplicationDbContext ctx = new Model.ApplicationDbContext())
            {
                try
                {
                    ctx.Configuration.ProxyCreationEnabled = false;
                    List<Model.LeaveModel.HolidayList> holiDaysList = ctx.HolidayList.ToList();
                    if (TempData["Message"] != null)
                    {
                        ViewBag.message = TempData["Message"];
                    }
                    return View(holiDaysList);
                }
                catch (Exception ex)
                {
                    return View();
                }
                finally
                {
                    ctx.Configuration.ProxyCreationEnabled = true;
                }
            }
           
        }
           
    }
}